<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Popup\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;

/**
 * Popup mysql resource
 */
class Instance extends \Magento\Widget\Model\ResourceModel\Widget\Instance
{
}
