/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

var config = {
    paths: {
        'tigren/popup': 'Tigren_Popup/js/jquery.popup',
    },
    shim: {
        'tigren/popup': {
            deps: ['jquery']
        }
    }
};
