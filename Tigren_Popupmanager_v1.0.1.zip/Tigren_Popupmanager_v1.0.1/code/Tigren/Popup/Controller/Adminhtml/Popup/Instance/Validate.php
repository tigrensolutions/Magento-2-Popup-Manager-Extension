<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Popup\Controller\Adminhtml\Popup\Instance;

class Validate extends \Magento\Widget\Controller\Adminhtml\Widget\Instance\Validate
{
}
